const { MessageEmbed } = require("discord.js");
const { TrackUtils } = require("erela.js");

  module.exports = {
    name: "remove",
    description: `Remove a song from the queue`,
    usage: "[number]",
    permissions: {
      channel: ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"],
      member: [],
    },
    aliases: ["rm"],

    /**
   *
   * @param {import("../structures/DiscordMusicBot")} client
   * @param {import("discord.js").Message} message
   * @param {string[]} args
   * @param {*} param3
   */
  run: async (client, message, args, { GuildDB }) => {
    let player = await client.Manager.players.get(message.guild.id);
    if (!player) return client.sendTime(message.channel, "❌ | **現在沒有正在播放的音樂...**");
    if (!message.member.voice.channel) return client.sendTime(message.channel, "❌ | **你必須在語音頻道才可使用此指令!**");
    if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return client.sendTime(message.channel, ":x: | **你必須與我在同個語音頻道才可使用此指令!**");
        
    if (!player.queue || !player.queue.length || player.queue.length === 0)
      return client.sendTime(message.channel,"❌ | 列隊中沒有可刪除的歌曲!");
    let rm = new MessageEmbed()
      .setDescription(`✅ **|** 從歌單中刪除第 **\`${Number(args[0])}\`** 首歌曲!`)
      .setColor("GREEN")
      if (isNaN(args[0]))rm.setDescription(`**用法 - **${GuildDB.prefix}\`remove [歌單編號]\``);
      if (args[0] > player.queue.length)
      rm.setDescription(`歌單只有 ${player.queue.length} 首歌曲!`);
    await message.channel.send(rm);
    player.queue.remove(Number(args[0]) - 1);
  },

  SlashCommand: {
    options: [
      {
          name: "remove",
          value: "[number]",
          type: 4,
          required: true,
          description: "Remove a song from the queue",
      },
  ],
  /**
   *
   * @param {import("../structures/DiscordMusicBot")} client
   * @param {import("discord.js").Message} message
   * @param {string[]} args
   * @param {*} param3
   */
    run: async (client, interaction, args, { GuildDB }) => {
      let player = await client.Manager.get(interaction.guild_id);
      if (!player) return client.sendTime("❌ | **Nothing is playing right now...**");
      if (!member.voice.channel) return client.sendTime(interaction, "❌ | **You must be in a voice channel to use this command.**");
      if (guild.me.voice.channel && !guild.me.voice.channel.equals(member.voice.channel)) return client.sendTime(interaction, `❌ | **You must be in ${guild.me.voice.channel} to use this command.**`);
  
      if (!player.queue || !player.queue.length || player.queue.length === 0)
      return client.sendTime("❌ | **Nothing is playing right now...**");
    let rm = new MessageEmbed()
      .setDescription(`✅ **|** Removed track **\`${Number(args[0])}\`** from the queue!`)
      .setColor("GREEN")
      if (isNaN(args[0]))rm.setDescription(`Usage: ${client.config.prefix}\`remove [number]\``);
      if (args[0] > player.queue.length)
      rm.setDescription(`The queue has only ${player.queue.length}!`);
    await interaction.send(rm);
      player.queue.remove(Number(args[0]) - 1);
    },
  }
}